# ColebrookWhite
Python Package for calculating QFull for a circular pipe using Colebrook Whites formula

<b>To install:</b>

```
python -m pip install https://github.com/enielsen93/ColebrookWhite/tarball/master
```
